clear && ./rand_test.sh 
./run.sh std test_results/input_20250721_213109.txt
DEBUG=1 ./run.sh main test_results/input_20250721_213109.txt